﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfRegister
{
    public static class RunTimeVariables
    {
        public static string TokenString { get; set; }
        public const string  DeviceName  = "Vaškova Appka";
        public static int IdUser { get; set; }
    }
}
